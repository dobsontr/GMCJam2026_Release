Thanks for taking the time to judge my entry. Appreciated.

Prior to the jam, I had the following done:
Project made
Github ready
'Prototype' of the input queue and 'star movement' 

The latter was not used at all (except in my brain haha - how I implemented it, problems
with the way I did it)

Cheers again,
Tim.