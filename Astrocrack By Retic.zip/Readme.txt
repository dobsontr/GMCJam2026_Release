Hope you enjoy the game!

This is my first ever GameMaker game so be nice :)

Any bugs or useful feedback more than welcome.
You can PM me on the gamemaker forum - username Retic.

No AI was used to make this game.. at least intentionally - some of the public 
art assets may have been and not labelled as AI generated but I dont think so.

A few files get saved locally to here on my computer:
Users\<username>\AppData\Local\Astrocrack 
They are tiny, total: ~606 bytes
But you still might want to clean them up when done

I never got around to doing the Settings option (sorry)
but if you feel inclined, most settings are in the above files.

Pro tip for reading to the end: The Crack sequence is very useful
 - especially in early levels - to get more stars to survive later on.