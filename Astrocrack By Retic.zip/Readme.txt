Hope you enjoy the game!

This is my first ever GameMaker game so be nice :)

Any bugs or useful feedback more than welcome.
You can PM me on the gamemaker forum - username Retic.

A few files get saved locally to here on my computer:
Users\<username>\AppData\Local\Astrocrack 
They are tiny, total: ~606 bytes
But you still might want to clean them up when done


